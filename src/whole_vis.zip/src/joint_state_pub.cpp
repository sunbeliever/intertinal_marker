#include "joint_state_pub.h"

void print_time_point(std::chrono::system_clock::time_point timePoint) {
  std::time_t timeStamp = std::chrono::system_clock::to_time_t(timePoint);
  std::cout << std::ctime(&timeStamp) << std::endl;
}

// ros2 action send_goal /my_group_controller/follow_joint_trajectory control_msgs/action/FollowJointTrajectory "
JointStatePub::JointStatePub(std::string name) : Node(name) {
  using namespace std::placeholders;  // NOLINT
  RCLCPP_INFO(this->get_logger(), "JointStatePub: construct.");

  joint_states_publisher = this->create_publisher<sensor_msgs::msg::JointState>("/joint_states", 100);

  joint_state_subscription =
      this->create_subscription<sensor_msgs::msg::JointState>("/joint_states", 100, std::bind(&JointStatePub::joint_state_subscription_cb, this, _1));

  command_joint_state_msg_.position.resize(24, 0.0);
  command_joint_state_msg_.velocity.resize(24, 0.0);
  command_joint_state_msg_.effort.resize(24, 0.0);
  command_joint_state_msg_.position.resize(24, 0.0);

  cur_joint_state_msg_.position.resize(24, 0.0);
  cur_joint_state_msg_.velocity.resize(24, 0.0);
  cur_joint_state_msg_.effort.resize(24, 0.0);
  cur_joint_state_msg_.position.resize(24, 0.0);

  joint_state_publish_thread_ptr = std::make_shared<std::thread>(std::bind(&JointStatePub::JointStatePublishThread, this));
}

JointStatePub::~JointStatePub() {
  stop_flag = true;
  joint_state_publish_thread_ptr->join();
}

void JointStatePub ::publish_joint_command() {
  std::unique_lock<std::mutex> lock(joint_command_mutex_);

  command_joint_state_msg_.name = {
      "1-joint-left-hip-roll",  "1-joint-left-hip-yaw",  "1-joint-left-hip-pitch",  "1-joint-left-tarsus",  "1-joint-left-foot",
      "2-joint-right-hip-roll", "2-joint-right-hip-yaw", "2-joint-right-hip-pitch", "2-joint-right-tarsus", "2-joint-right-foot",
      "3-left-arm-joint01",     "3-left-arm-joint02",    "3-left-arm-joint03",      "3-left-arm-joint04",   "3-left-arm-joint05",
      "3-left-arm-joint06",     "3-left-arm-joint07",    "4-right-arm-joint01",     "4-right-arm-joint02",  "4-right-arm-joint03",
      "4-right-arm-joint04",    "4-right-arm-joint05",   "4-right-arm-joint06",     "4-right-arm-joint07",
  };

  command_joint_state_msg_.header.stamp = this->now();
  for (int ii = 0; ii < 24; ii++) {
    command_joint_state_msg_.position[ii] += 0.00001;  // run()  command
    command_joint_state_msg_.velocity[ii] = 1.1;
    command_joint_state_msg_.effort[ii] = 1.1;
  }
  joint_states_publisher->publish(command_joint_state_msg_);
}

void JointStatePub::joint_state_subscription_cb(sensor_msgs::msg::JointState::UniquePtr msg) {
  std::unique_lock<std::mutex> lock(joint_state_mutex_);

  cur_joint_state_msg_.name = {
      "1-joint-left-hip-roll",  "1-joint-left-hip-yaw",  "1-joint-left-hip-pitch",  "1-joint-left-tarsus",  "1-joint-left-foot",
      "2-joint-right-hip-roll", "2-joint-right-hip-yaw", "2-joint-right-hip-pitch", "2-joint-right-tarsus", "2-joint-right-foot",
      "3-left-arm-joint01",     "3-left-arm-joint02",    "3-left-arm-joint03",      "3-left-arm-joint04",   "3-left-arm-joint05",
      "3-left-arm-joint06",     "3-left-arm-joint07",    "4-right-arm-joint01",     "4-right-arm-joint02",  "4-right-arm-joint03",
      "4-right-arm-joint04",    "4-right-arm-joint05",   "4-right-arm-joint06",     "4-right-arm-joint07",
  };
  cur_joint_state_msg_.header.stamp = this->now();
  for (int ii = 0; ii < 24; ii++) {
    cur_joint_state_msg_.position[ii] = msg->position[ii];
    cur_joint_state_msg_.velocity[ii] = 0;
    cur_joint_state_msg_.effort[ii] = 0;
  }
  joint_states_publisher->publish(cur_joint_state_msg_);

  publish_joint_command();
}

void JointStatePub::JointStatePublishThread() {
  RCLCPP_INFO(this->get_logger(), "JointStatePublishThread. start joint state publish.");
  while (!stop_flag) {
    publish_joint_command();
    std::this_thread::sleep_for(std::chrono::milliseconds(5));
  }
}
int main(int argc, char** argv) {
  rclcpp::init(argc, argv);
  auto node_ptr = std::make_shared<JointStatePub>("joint_state_pub");
  rclcpp::spin(node_ptr);
  return 0;
}
