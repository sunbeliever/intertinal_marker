#ifndef MYACTIONROBOT_H
#define MYACTIONROBOT_H

#include "rclcpp/rclcpp.hpp"
#include "rclcpp_action/rclcpp_action.hpp"

#include "control_msgs/action/follow_joint_trajectory.hpp"
#include "sensor_msgs/msg/joint_state.hpp"

#include <memory>
#include <mutex>
#include <thread>

class JointStatePub : public rclcpp::Node {
 public:
  using FollowJointTrajectory = control_msgs::action::FollowJointTrajectory;
  using GoalHandleFJT = rclcpp_action::ServerGoalHandle<FollowJointTrajectory>;
  explicit JointStatePub(std::string name);
  ~JointStatePub();

 private:
  void publish_joint_command();
  void joint_state_subscription_cb(sensor_msgs::msg::JointState::UniquePtr msg);

  void JointStatePublishThread();

 private:
  rclcpp::Publisher<sensor_msgs::msg::JointState>::SharedPtr joint_states_publisher;
  rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr joint_state_subscription;
  std::mutex joint_state_mutex_;
  std::mutex joint_command_mutex_;

  sensor_msgs::msg::JointState command_joint_state_msg_;
  sensor_msgs::msg::JointState cur_joint_state_msg_;

  bool stop_flag = false;
  std::shared_ptr<std::thread> joint_state_publish_thread_ptr;
};

#endif  // MYACTIONROBOT_H
